<?php 
exec('python /analyze_behavior.py'); 
?>
